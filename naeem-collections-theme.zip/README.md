# Naeem Collections

Online Store 2.0 theme. Orders go out on WhatsApp. There is no checkout button.

## Upload

In Shopify admin: Online Store → Themes → Add theme → Upload zip.

Set the store currency to PKR.

## Collections

Create these collections and use the handles exactly:

- kids-boys, girls, mens
- boys-pants, boys-shirts, boys-tracksuits, boys-shorts, boys-sets, boys-6-pocket-trousers
- girls-tops, girls-2pc-suits, girls-pants
- mens-pants, mens-shirts, mens-6-pocket-trousers, mens-belts

Kids Boys, Girls, and Mens open as sub-collection grids. The others show their products.

## Pages

Create pages with handles `about`, `shipping`, and `contact`. The theme fills them until you write your own page body. About, shipping, and contact copy is also editable on the page section in the theme editor.

## Homepage

Until you choose a collection that already has products, Featured Products shows eight sample cards with photos and PKR prices. Hero slides, category cards, announcement text, logo, colours, and store details are all editable in the theme editor.
